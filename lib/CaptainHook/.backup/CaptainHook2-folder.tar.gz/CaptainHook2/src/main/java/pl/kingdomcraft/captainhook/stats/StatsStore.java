package pl.kingdomcraft.captainhook.stats;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import pl.kingdomcraft.captainhook.database.Database;
import pl.kingdomcraft.captainhook.database.Database.Tables;
import pl.kingdomcraft.captainhook.settings.Settings;

/**
 * SQL of the stats tables, read by the website:
 *
 * - ch_player_stats       one row per (server_id, uuid), absolute snapshot of that server's stats
 * - ch_player_stats_total one row per uuid, network-wide sums maintained here, indexed for leaderboards
 *
 * Stats rows and totals are written in two transactions. A server only locks its own stats rows, so two servers
 * updating the same player (e.g. on a server switch) cannot deadlock on each other's rows.
 */
public final class StatsStore {

	private static final int CHUNK_SIZE = 500;

	private static final String[] STATS_COLUMNS = { "server_id", "uuid", "nickname", "balance", "level", "playtime_seconds", "blocks_placed",
			"player_kills", "mob_kills", "deaths", "clan_tag", "online", "last_seen", "updated_at" };

	private static final String[] TOTAL_COLUMNS = { "uuid", "nickname", "playtime_seconds", "blocks_placed", "player_kills", "mob_kills", "deaths",
			"online", "last_seen", "updated_at" };

	private StatsStore() {
	}

	/**
	 * Saves the snapshots and refreshes the totals of their players.
	 */
	static CompletableFuture<Void> save(final List<PlayerSnapshot> snapshots) {
		final Set<String> uuids = new LinkedHashSet<>();

		for (final PlayerSnapshot snapshot : snapshots)
			uuids.add(snapshot.uuid.toString());

		// Both are queued right away (the database thread runs them in order), so this also works during shutdown
		final CompletableFuture<Void> saved = Database.submit(connection -> {
			saveSnapshots(connection, snapshots, !Database.isMySql());

			return null;
		});

		final CompletableFuture<Void> totals = Database.submit(connection -> {
			refreshTotals(connection, uuids, !Database.isMySql());

			return null;
		});

		return saved.thenCombine(totals, (first, second) -> null);
	}

	/**
	 * Marks every player of this server offline. Called on startup, as a crash or kill skips the quit snapshots.
	 */
	static CompletableFuture<Void> markServerOffline() {
		return Database.submit(connection -> {
			final List<String> uuids = new ArrayList<>();

			try (PreparedStatement statement = connection.prepareStatement("SELECT uuid FROM " + Tables.STATS + " WHERE server_id = ? AND online = 1")) {
				statement.setString(1, Settings.Api.SERVER_ID);

				try (ResultSet result = statement.executeQuery()) {
					while (result.next())
						uuids.add(result.getString(1));
				}
			}

			if (uuids.isEmpty())
				return null;

			try (PreparedStatement statement = connection.prepareStatement("UPDATE " + Tables.STATS + " SET online = 0 WHERE server_id = ?")) {
				statement.setString(1, Settings.Api.SERVER_ID);
				statement.executeUpdate();
			}

			refreshTotals(connection, uuids, !Database.isMySql());
			return null;
		});
	}

	private static void saveSnapshots(final Connection connection, final List<PlayerSnapshot> snapshots, final boolean sqlite) throws SQLException {
		final long now = System.currentTimeMillis() / 1000;

		try (PreparedStatement statement = connection.prepareStatement(upsert(Tables.STATS, STATS_COLUMNS, 2, sqlite))) {
			int batched = 0;

			for (final PlayerSnapshot snapshot : snapshots) {
				statement.setString(1, Settings.Api.SERVER_ID);
				statement.setString(2, snapshot.uuid.toString());
				statement.setString(3, snapshot.nickname);
				statement.setBigDecimal(4, snapshot.balance);
				statement.setInt(5, snapshot.level);
				statement.setLong(6, snapshot.playtimeSeconds);
				statement.setLong(7, snapshot.blocksPlaced);
				statement.setInt(8, snapshot.playerKills);
				statement.setInt(9, snapshot.mobKills);
				statement.setInt(10, snapshot.deaths);
				statement.setString(11, snapshot.clanTag);
				statement.setBoolean(12, snapshot.online);
				statement.setLong(13, snapshot.lastSeen);
				statement.setLong(14, now);
				statement.addBatch();

				if (++batched % CHUNK_SIZE == 0)
					statement.executeBatch();
			}

			statement.executeBatch();
		}
	}

	/**
	 * Recomputes network-wide sums of the given players from all servers' rows.
	 */
	static void refreshTotals(final Connection connection, final Collection<String> uuids, final boolean sqlite) throws SQLException {
		final List<String> list = new ArrayList<>(uuids);
		final long now = System.currentTimeMillis() / 1000;
		final String insert = "INSERT INTO " + Tables.STATS_TOTAL + " (" + String.join(", ", TOTAL_COLUMNS) + ") "
				+ "SELECT s.uuid, "
				+ "(SELECT n.nickname FROM " + Tables.STATS + " n WHERE n.uuid = s.uuid ORDER BY n.last_seen DESC LIMIT 1), "
				+ "SUM(s.playtime_seconds), SUM(s.blocks_placed), SUM(s.player_kills), SUM(s.mob_kills), SUM(s.deaths), "
				+ "MAX(s.online), MAX(s.last_seen), ? "
				+ "FROM " + Tables.STATS + " s WHERE s.uuid IN (%s) GROUP BY s.uuid "
				+ updateClause(TOTAL_COLUMNS, 1, sqlite);

		for (int from = 0; from < list.size(); from += CHUNK_SIZE) {
			final List<String> chunk = list.subList(from, Math.min(from + CHUNK_SIZE, list.size()));

			try (PreparedStatement statement = connection.prepareStatement(String.format(insert, String.join(", ", Collections.nCopies(chunk.size(), "?"))))) {
				statement.setLong(1, now);

				for (int i = 0; i < chunk.size(); i++)
					statement.setString(i + 2, chunk.get(i));

				statement.executeUpdate();
			}
		}
	}

	/**
	 * Copies stats rows from an old SQLite database to the target if they are newer there, then refreshes totals.
	 * Copied rows are marked offline.
	 *
	 * @return the number of copied rows
	 */
	public static long merge(final Connection source, final Connection target, final boolean targetSqlite) throws SQLException {
		final Set<String> merged = new LinkedHashSet<>();

		try (PreparedStatement read = source.prepareStatement("SELECT " + String.join(", ", STATS_COLUMNS) + " FROM " + Tables.STATS);
				ResultSet rows = read.executeQuery();
				PreparedStatement current = target.prepareStatement("SELECT updated_at FROM " + Tables.STATS + " WHERE server_id = ? AND uuid = ?");
				PreparedStatement write = target.prepareStatement(upsert(Tables.STATS, STATS_COLUMNS, 2, targetSqlite))) {

			while (rows.next()) {
				current.setString(1, rows.getString("server_id"));
				current.setString(2, rows.getString("uuid"));

				try (ResultSet existing = current.executeQuery()) {
					if (existing.next() && existing.getLong(1) >= rows.getLong("updated_at"))
						continue;
				}

				for (int i = 0; i < STATS_COLUMNS.length; i++)
					write.setObject(i + 1, STATS_COLUMNS[i].equals("online") ? Boolean.FALSE : rows.getObject(STATS_COLUMNS[i]));

				write.executeUpdate();
				merged.add(rows.getString("uuid"));
			}
		}

		refreshTotals(target, merged, targetSqlite);
		return merged.size();
	}

	/**
	 * INSERT ... ON DUPLICATE KEY UPDATE (MySQL) / ON CONFLICT DO UPDATE (SQLite) over all columns,
	 * the first keyColumns being the primary key.
	 */
	private static String upsert(final String table, final String[] columns, final int keyColumns, final boolean sqlite) {
		return "INSERT INTO " + table + " (" + String.join(", ", columns) + ") VALUES (" + String.join(", ", Collections.nCopies(columns.length, "?")) + ") "
				+ updateClause(columns, keyColumns, sqlite);
	}

	private static String updateClause(final String[] columns, final int keyColumns, final boolean sqlite) {
		final List<String> updates = new ArrayList<>();

		for (int i = keyColumns; i < columns.length; i++)
			updates.add(columns[i] + " = " + (sqlite ? "excluded." + columns[i] : "VALUES(" + columns[i] + ")"));

		final List<String> keys = new ArrayList<>();

		for (int i = 0; i < keyColumns; i++)
			keys.add(columns[i]);

		return (sqlite ? "ON CONFLICT(" + String.join(", ", keys) + ") DO UPDATE SET " : "ON DUPLICATE KEY UPDATE ") + String.join(", ", updates);
	}
}
