package pl.kingdomcraft.captainhook.settings;

import java.util.List;

import org.mineacademy.fo.settings.SimpleLocalization;

/**
 * Maps localization/messages_{Locale}.yml.
 */
public final class Localization extends SimpleLocalization {

	@Override
	protected int getConfigVersion() {
		return 1;
	}

	public static final class Link {

		public static String DESCRIPTION;
		public static String STATUS_LINKED;
		public static String STATUS_NOT_LINKED;
		public static String INVALID_FORMAT;
		public static String VERIFYING;
		public static String SUCCESS;
		public static String INVALID_CODE;
		public static String NICKNAME_MISMATCH;
		public static String ALREADY_LINKED;
		public static String RATE_LIMITED;
		public static String CONFIG_ERROR;
		public static String UNAVAILABLE;

		private static void init() {
			setPathPrefix("Link");

			DESCRIPTION = getString("Description");
			STATUS_LINKED = getString("Status_Linked");
			STATUS_NOT_LINKED = getString("Status_Not_Linked");
			INVALID_FORMAT = getString("Invalid_Format");
			VERIFYING = getString("Verifying");
			SUCCESS = getString("Success");
			INVALID_CODE = getString("Invalid_Code");
			NICKNAME_MISMATCH = getString("Nickname_Mismatch");
			ALREADY_LINKED = getString("Already_Linked");
			RATE_LIMITED = getString("Rate_Limited");
			CONFIG_ERROR = getString("Config_Error");
			UNAVAILABLE = getString("Unavailable");
		}
	}

	public static final class Coins {

		public static String DESCRIPTION_BALANCE;
		public static String DESCRIPTION_PAY;
		public static String DESCRIPTION_TOP;
		public static String DESCRIPTION_GIVE;
		public static String DESCRIPTION_TAKE;
		public static String DESCRIPTION_SET;
		public static String DESCRIPTION_HISTORY;
		public static String BALANCE;
		public static String BALANCE_OTHER;
		public static String BALANCE_CHANGED;
		public static String LOADING;
		public static String PLAYER_NOT_FOUND;
		public static String INVALID_AMOUNT;
		public static String INVALID_PAGE;
		public static String NOT_ENOUGH;
		public static String PAY_SELF;
		public static String PAY_SENT;
		public static String PAY_RECEIVED;
		public static String TOP_HEADER;
		public static String TOP_LINE;
		public static String TOP_EMPTY;
		public static String ADMIN_GIVE;
		public static String ADMIN_TAKE;
		public static String ADMIN_SET;
		public static String ADMIN_NOT_ENOUGH;
		public static String HISTORY_HEADER;
		public static String HISTORY_LINE;
		public static String HISTORY_EMPTY;
		public static String DATABASE_ERROR;

		private static void init() {
			setPathPrefix("KingdomCoins");

			DESCRIPTION_BALANCE = getString("Description_Balance");
			DESCRIPTION_PAY = getString("Description_Pay");
			DESCRIPTION_TOP = getString("Description_Top");
			DESCRIPTION_GIVE = getString("Description_Give");
			DESCRIPTION_TAKE = getString("Description_Take");
			DESCRIPTION_SET = getString("Description_Set");
			DESCRIPTION_HISTORY = getString("Description_History");
			BALANCE = getString("Balance");
			BALANCE_OTHER = getString("Balance_Other");
			BALANCE_CHANGED = getString("Balance_Changed");
			LOADING = getString("Loading");
			PLAYER_NOT_FOUND = getString("Player_Not_Found");
			INVALID_AMOUNT = getString("Invalid_Amount");
			INVALID_PAGE = getString("Invalid_Page");
			NOT_ENOUGH = getString("Not_Enough");
			PAY_SELF = getString("Pay_Self");
			PAY_SENT = getString("Pay_Sent");
			PAY_RECEIVED = getString("Pay_Received");
			TOP_HEADER = getString("Top_Header");
			TOP_LINE = getString("Top_Line");
			TOP_EMPTY = getString("Top_Empty");
			ADMIN_GIVE = getString("Admin_Give");
			ADMIN_TAKE = getString("Admin_Take");
			ADMIN_SET = getString("Admin_Set");
			ADMIN_NOT_ENOUGH = getString("Admin_Not_Enough");
			HISTORY_HEADER = getString("History_Header");
			HISTORY_LINE = getString("History_Line");
			HISTORY_EMPTY = getString("History_Empty");
			DATABASE_ERROR = getString("Database_Error");
		}
	}

	public static final class Admin {

		public static List<String> STATUS;
		public static String DESCRIPTION_STATUS;
		public static String DESCRIPTION_MERGE;
		public static String SQLITE_FILE_PRESENT;
		public static String MERGE_NOT_MYSQL;
		public static String MERGE_NO_FILE;
		public static String MERGE_RUNNING;
		public static String MERGE_PREVIEW;
		public static String MERGE_STARTED;
		public static String MERGE_DONE;
		public static String MERGE_FAILED;

		private static void init() {
			setPathPrefix("Admin");

			STATUS = getStringList("Status");
			DESCRIPTION_STATUS = getString("Description_Status");
			DESCRIPTION_MERGE = getString("Description_Merge");
			SQLITE_FILE_PRESENT = getString("Sqlite_File_Present");
			MERGE_NOT_MYSQL = getString("Merge_Not_Mysql");
			MERGE_NO_FILE = getString("Merge_No_File");
			MERGE_RUNNING = getString("Merge_Running");
			MERGE_PREVIEW = getString("Merge_Preview");
			MERGE_STARTED = getString("Merge_Started");
			MERGE_DONE = getString("Merge_Done");
			MERGE_FAILED = getString("Merge_Failed");
		}
	}
}
