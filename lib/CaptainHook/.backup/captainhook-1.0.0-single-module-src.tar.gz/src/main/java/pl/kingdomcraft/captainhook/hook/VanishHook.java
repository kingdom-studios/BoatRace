package pl.kingdomcraft.captainhook.hook;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.mineacademy.fo.annotation.AutoRegister;

import de.myzelyam.api.vanish.PostPlayerHideEvent;
import de.myzelyam.api.vanish.PostPlayerShowEvent;
import de.myzelyam.api.vanish.VanishAPI;
import pl.kingdomcraft.captainhook.stats.StatsTracker;

/**
 * SuperVanish integration (required dependency). Players in vanish are saved with vanished = 1: the website
 * shows them as offline everywhere (rankings, online counts) except on their own dashboard ("On vanish").
 *
 * Toggling vanish marks the player dirty, so the website sees the change within a few seconds.
 */
@AutoRegister
public final class VanishHook implements Listener {

	/**
	 * Main thread only.
	 */
	public static boolean isVanished(final Player player) {
		return VanishAPI.isInvisible(player);
	}

	@EventHandler(priority = EventPriority.MONITOR)
	public void onHide(final PostPlayerHideEvent event) {
		StatsTracker.markDirty(event.getPlayer().getUniqueId());
	}

	@EventHandler(priority = EventPriority.MONITOR)
	public void onShow(final PostPlayerShowEvent event) {
		StatsTracker.markDirty(event.getPlayer().getUniqueId());
	}
}
