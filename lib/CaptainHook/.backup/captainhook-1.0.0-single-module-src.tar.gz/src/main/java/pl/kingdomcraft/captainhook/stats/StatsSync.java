package pl.kingdomcraft.captainhook.stats;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.mineacademy.fo.Common;
import org.mineacademy.fo.model.SimpleTask;
import org.mineacademy.fo.remain.Remain;

import pl.kingdomcraft.captainhook.settings.Settings;

/**
 * Writes player stat snapshots to the database in near real time, the website reads them from there.
 *
 * Every stats.realtime-interval-seconds only players marked dirty by {@link StatsTracker} are saved, and every
 * stats.sync-interval-minutes all online players (to refresh playtime and the online heartbeat). Snapshots wait in
 * {@link #pending} (one per player, newest wins) and at most one save is in flight, so bursts of changes or a slow
 * database coalesce into fewer, larger batches. On database errors the snapshots are kept and saving pauses with
 * exponential backoff.
 */
public final class StatsSync {

	private static final long BASE_BACKOFF_MILLIS = 5_000;
	private static final long MAX_BACKOFF_MILLIS = 5 * 60_000;

	/**
	 * All fields are accessed on the main thread only.
	 */
	private static final Map<UUID, PlayerSnapshot> pending = new LinkedHashMap<>();

	private static SimpleTask timer;
	private static int ticksUntilFullSync;
	private static boolean saving;
	private static int failures;
	private static long pausedUntil;

	private StatsSync() {
	}

	public static void start() {
		stop();

		ticksUntilFullSync = 0; // save everyone online right away, e.g. after a reload
		timer = Common.runTimer(Settings.Stats.REALTIME_INTERVAL_TICKS, Settings.Stats.REALTIME_INTERVAL_TICKS, StatsSync::tick);
	}

	public static void stop() {
		if (timer != null)
			timer.cancel();

		timer = null;
	}

	/**
	 * Marks players left online by a crash of this server as offline. Call once on startup.
	 */
	public static void resetOnlineFlags() {
		StatsStore.markServerOffline().whenComplete((ignored, error) -> {
			if (error != null)
				Common.error(error, "Could not reset online flags of server " + Settings.Api.SERVER_ID);
		});
	}

	/**
	 * Queues the snapshot of a player, saved with the next tick.
	 *
	 * @param online false for a player leaving the server
	 */
	static void queue(final Player player, final boolean online) {
		pending.put(player.getUniqueId(), PlayerSnapshot.of(player, online));
	}

	public static int getPendingCount() {
		return pending.size();
	}

	private static void tick() {
		if ((ticksUntilFullSync -= Settings.Stats.REALTIME_INTERVAL_TICKS) <= 0) {
			ticksUntilFullSync = Settings.Stats.SYNC_INTERVAL_TICKS;

			StatsTracker.clearDirty();

			for (final Player player : Remain.getOnlinePlayers())
				queue(player, true);

		} else
			for (final UUID uuid : StatsTracker.drainDirty()) {
				final Player player = Bukkit.getPlayer(uuid);

				if (player != null)
					queue(player, true);
			}

		if (!saving && !pending.isEmpty() && System.currentTimeMillis() >= pausedUntil)
			save();
	}

	private static void save() {
		final List<PlayerSnapshot> snapshots = new ArrayList<>(pending.values());

		pending.clear();
		saving = true;

		StatsStore.save(snapshots).whenComplete((ignored, error) -> Common.runLater(() -> onSaved(snapshots, error)));
	}

	private static void onSaved(final List<PlayerSnapshot> snapshots, final Throwable error) {
		saving = false;

		if (error == null) {
			failures = 0;

			return;
		}

		// A newer snapshot queued in the meantime wins over the failed one
		for (final PlayerSnapshot snapshot : snapshots)
			pending.putIfAbsent(snapshot.uuid, snapshot);

		final long backoff = Math.min(MAX_BACKOFF_MILLIS, BASE_BACKOFF_MILLIS << Math.min(failures++, 10));

		pausedUntil = System.currentTimeMillis() + backoff;
		Common.log("&cCould not save stats (" + error.getMessage() + "), " + pending.size() + " snapshot(s) kept, retrying in " + backoff / 1000 + "s.");
	}

	/**
	 * Queues the final snapshots of everyone online, marked offline. The database thread finishes them
	 * before the connection is closed, see Database#shutdown.
	 */
	public static void shutdown() {
		stop();

		for (final Player player : Remain.getOnlinePlayers())
			queue(player, false);

		if (!pending.isEmpty())
			StatsStore.save(new ArrayList<>(pending.values()));

		pending.clear();
	}
}
