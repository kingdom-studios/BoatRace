package pl.kingdomcraft.captainhook.coins;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.entity.Player;
import org.mineacademy.fo.Common;
import org.mineacademy.fo.model.SimpleTask;
import org.mineacademy.fo.remain.Remain;

import pl.kingdomcraft.captainhook.database.Database;
import pl.kingdomcraft.captainhook.settings.Settings;

/**
 * KingdomCoins - the network-wide premium currency. Public API for commands, placeholders and other plugins.
 *
 * Every write goes to the database (never to a cache) and returns a future completed on the database thread,
 * failing with SQLException when the database is unavailable. Balances of online players and the top list
 * are cached for placeholders and refreshed periodically, so changes made on other servers or directly in the
 * database (e.g. by the web shop) show up within kingdomcoins.refresh-interval-seconds.
 */
public final class KingdomCoins {

	public static final int TOP_SIZE = 10;
	public static final long MAX_AMOUNT = 1_000_000_000_000L;

	private static final Map<UUID, Long> balances = new ConcurrentHashMap<>();
	private static volatile List<CoinAccount> top = Collections.emptyList();
	private static SimpleTask refreshTask;

	private KingdomCoins() {
	}

	/* ------------------------------------------------------------------------------- */
	/* Lifecycle */
	/* ------------------------------------------------------------------------------- */

	public static void start() {
		stop();

		refreshTask = Common.runTimer(0, Settings.KingdomCoins.REFRESH_INTERVAL_TICKS, KingdomCoins::refresh);
	}

	public static void stop() {
		if (refreshTask != null)
			refreshTask.cancel();

		refreshTask = null;
	}

	/**
	 * Creates the account if needed and caches the balance. Called on join.
	 */
	public static void load(final Player player) {
		final UUID uuid = player.getUniqueId();

		Database.submit(connection -> CoinStore.load(connection, uuid, player.getName(), !Database.isMySql()))
				.whenComplete((balance, error) -> {
					if (error != null)
						Common.error(error, "Failed to load KingdomCoins of " + player.getName());

					else if (player.isOnline())
						updateCache(uuid, balance);
				});
	}

	public static void unload(final UUID uuid) {
		balances.remove(uuid);
	}

	/**
	 * Reloads cached balances of online players and the top list in one database round.
	 */
	public static void refresh() {
		final List<UUID> online = new ArrayList<>();

		for (final Player player : Remain.getOnlinePlayers())
			online.add(player.getUniqueId());

		Database.submit(connection -> {
			top = Collections.unmodifiableList(CoinStore.getTop(connection, TOP_SIZE));

			return CoinStore.getBalances(connection, online);

		}).whenComplete((fresh, error) -> {
			if (error != null) {
				Common.log("&cCould not refresh KingdomCoins: " + error);

				return;
			}

			balances.keySet().retainAll(online);
			fresh.forEach(KingdomCoins::updateCache);
		});
	}

	private static void updateCache(final UUID uuid, final long balance) {
		balances.put(uuid, balance);
	}

	/* ------------------------------------------------------------------------------- */
	/* Reading */
	/* ------------------------------------------------------------------------------- */

	/**
	 * @return the cached balance of an online player, or -1 if not loaded yet. Thread-safe and non-blocking.
	 */
	public static long getCachedBalance(final UUID uuid) {
		return balances.getOrDefault(uuid, -1L);
	}

	/**
	 * @return the cached richest players, at most {@link #TOP_SIZE}. Thread-safe and non-blocking.
	 */
	public static List<CoinAccount> getTop() {
		return top;
	}

	/**
	 * @return the account with this name (case-insensitive), or null if the player never joined the network
	 */
	public static CompletableFuture<CoinAccount> find(final String name) {
		return Database.submit(connection -> CoinStore.findByName(connection, name));
	}

	public static CompletableFuture<List<CoinTransaction>> getHistory(final UUID uuid, final int limit, final int offset) {
		return Database.submit(connection -> CoinStore.getHistory(connection, uuid, limit, offset));
	}

	/* ------------------------------------------------------------------------------- */
	/* Writing */
	/* ------------------------------------------------------------------------------- */

	/**
	 * @param actor UUID of the player causing the change, "CONSOLE" or your plugin name
	 */
	public static CompletableFuture<CoinResult> give(final UUID uuid, final long amount, final TransactionType type, final String actor, final String reason) {
		checkAmount(amount);

		return change(uuid, amount, type, actor, reason);
	}

	/**
	 * Fails with {@link CoinResult.Status#INSUFFICIENT_FUNDS} instead of going below zero.
	 */
	public static CompletableFuture<CoinResult> take(final UUID uuid, final long amount, final TransactionType type, final String actor, final String reason) {
		checkAmount(amount);

		return change(uuid, -amount, type, actor, reason);
	}

	public static CompletableFuture<CoinResult> set(final UUID uuid, final long balance, final String actor, final String reason) {
		if (balance < 0 || balance > MAX_AMOUNT)
			throw new IllegalArgumentException("Balance must be between 0 and " + MAX_AMOUNT + ", got " + balance);

		return track(uuid, Database.submit(connection -> CoinStore.set(connection, uuid, balance, actor, reason)));
	}

	/**
	 * @return the sender's result, {@link CoinResult.Status#NOT_FOUND} if the receiver has no account
	 */
	public static CompletableFuture<CoinResult> pay(final UUID from, final UUID to, final long amount) {
		checkAmount(amount);

		if (from.equals(to))
			throw new IllegalArgumentException("Cannot pay to self");

		final CompletableFuture<CoinResult> future = Database.submit(connection -> CoinStore.transfer(connection, from, to, amount));

		// The receiver's new balance is unknown here, the next refresh picks it up
		future.thenAccept(result -> {
			if (result.isSuccess())
				balances.computeIfPresent(to, (uuid, balance) -> balance + amount);
		});

		return track(from, future);
	}

	private static CompletableFuture<CoinResult> change(final UUID uuid, final long amount, final TransactionType type, final String actor, final String reason) {
		return track(uuid, Database.submit(connection -> CoinStore.change(connection, uuid, amount, type, actor, reason)));
	}

	/**
	 * Updates the cache of an online player once the change is committed.
	 */
	private static CompletableFuture<CoinResult> track(final UUID uuid, final CompletableFuture<CoinResult> future) {
		future.thenAccept(result -> {
			if (result.isSuccess() && balances.containsKey(uuid))
				updateCache(uuid, result.getBalance());
		});

		return future;
	}

	private static void checkAmount(final long amount) {
		if (amount <= 0 || amount > MAX_AMOUNT)
			throw new IllegalArgumentException("Amount must be between 1 and " + MAX_AMOUNT + ", got " + amount);
	}

	/* ------------------------------------------------------------------------------- */
	/* Formatting */
	/* ------------------------------------------------------------------------------- */

	/**
	 * @return the amount with space-separated thousands, e.g. "1 250 000"
	 */
	public static String format(final long amount) {
		final DecimalFormatSymbols symbols = new DecimalFormatSymbols();

		symbols.setGroupingSeparator(' ');
		return new DecimalFormat("#,##0", symbols).format(amount);
	}
}
