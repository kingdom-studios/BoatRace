package pl.kingdomcraft.captainhook.settings;

import java.util.List;

import org.mineacademy.fo.settings.SimpleSettings;

/**
 * Maps config.yml. Key names under "api" follow the web integration contract.
 */
public final class Settings extends SimpleSettings {

	@Override
	protected String getSettingsFileName() {
		return "config.yml";
	}

	@Override
	protected int getConfigVersion() {
		return 1;
	}

	public static final class Api {

		public static String BASE_URL;
		public static String SERVER_ID;
		public static String SECRET;
		public static Integer TIMEOUT_MILLIS;

		private static void init() {
			setPathPrefix("api");

			BASE_URL = getString("base-url").replaceAll("/+$", "");
			SERVER_ID = getString("server-id");
			SECRET = getString("secret");
			TIMEOUT_MILLIS = Math.max(1, getInteger("timeout-seconds")) * 1000;
		}
	}

	public static final class Stats {

		public static Integer REALTIME_INTERVAL_TICKS;
		public static Integer SYNC_INTERVAL_TICKS;

		private static void init() {
			setPathPrefix("stats");

			REALTIME_INTERVAL_TICKS = Math.max(1, getInteger("realtime-interval-seconds")) * 20;
			SYNC_INTERVAL_TICKS = Math.max(1, getInteger("sync-interval-minutes")) * 60 * 20;
		}
	}

	/**
	 * Read once on startup, changes require a restart.
	 */
	public static final class Database {

		public static Boolean MYSQL_ENABLED;
		public static String HOST;
		public static Integer PORT;
		public static String NAME;
		public static String USERNAME;
		public static String PASSWORD;
		public static String PROPERTIES;

		private static void init() {
			setPathPrefix("database.mysql");

			MYSQL_ENABLED = getBoolean("enabled");
			HOST = getString("host");
			PORT = getInteger("port");
			NAME = getString("database");
			USERNAME = getString("username");
			PASSWORD = getString("password");
			PROPERTIES = getString("properties");
		}
	}

	public static final class KingdomCoins {

		public static List<String> COMMAND_ALIASES;
		public static Integer REFRESH_INTERVAL_TICKS;

		private static void init() {
			setPathPrefix("kingdomcoins");

			COMMAND_ALIASES = getStringList("command-aliases");
			REFRESH_INTERVAL_TICKS = Math.max(5, getInteger("refresh-interval-seconds")) * 20;
		}
	}
}
