package pl.kingdomcraft.captainhook.command.admin;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.bukkit.command.CommandSender;
import org.mineacademy.fo.Common;
import org.mineacademy.fo.command.SimpleSubCommand;
import org.mineacademy.fo.model.Replacer;

import pl.kingdomcraft.captainhook.Permissions;
import pl.kingdomcraft.captainhook.coins.KingdomCoins;
import pl.kingdomcraft.captainhook.database.Database;
import pl.kingdomcraft.captainhook.database.SqliteMerge;
import pl.kingdomcraft.captainhook.settings.Localization.Admin;

/**
 * /captainhook merge [confirm] - merges KingdomCoins and stats from the SQLite fallback database into MySQL,
 * see {@link SqliteMerge}.
 */
final class MergeSubCommand extends SimpleSubCommand {

	private static final AtomicBoolean running = new AtomicBoolean();

	MergeSubCommand() {
		super("merge");

		setUsage("[confirm]");
		setDescription(Admin.DESCRIPTION_MERGE);
		setPermission(Permissions.ADMIN);
	}

	@Override
	protected void onCommand() {
		checkBoolean(Database.isMySql(), Admin.MERGE_NOT_MYSQL);
		checkBoolean(SqliteMerge.getFile().exists(), Replacer.replaceArray(Admin.MERGE_NO_FILE, "file", Database.SQLITE_FILE));
		checkBoolean(!running.get(), Admin.MERGE_RUNNING);

		final CommandSender sender = this.sender;
		final boolean confirm = args.length > 0 && "confirm".equalsIgnoreCase(args[0]);

		if (!confirm) {
			SqliteMerge.preview().whenComplete((summary, error) -> Common.runLater(() -> {
				if (error != null)
					Common.tell(sender, Replacer.replaceArray(Admin.MERGE_FAILED, "error", error.getMessage()));
				else
					Common.tell(sender, Replacer.replaceArray(Admin.MERGE_PREVIEW, "file", Database.SQLITE_FILE, "accounts", summary[0],
							"coins", KingdomCoins.format(summary[1]), "label", getLabel()));
			}));

			return;
		}

		checkBoolean(running.compareAndSet(false, true), Admin.MERGE_RUNNING);
		tell(Admin.MERGE_STARTED);

		SqliteMerge.merge().whenComplete((merged, error) -> {
			running.set(false);

			if (error != null)
				Common.error(error, "Merging " + Database.SQLITE_FILE + " into MySQL failed, nothing was changed");
			else
				Common.log("Merged " + merged[0] + " KingdomCoins account(s) with " + merged[1] + " coins and " + merged[2] + " stats row(s) from " + Database.SQLITE_FILE + " into MySQL.");

			Common.runLater(() -> Common.tell(sender, error != null
					? Replacer.replaceArray(Admin.MERGE_FAILED, "error", error.getMessage())
					: Replacer.replaceArray(Admin.MERGE_DONE, "accounts", merged[0], "coins", KingdomCoins.format(merged[1]), "stats", merged[2])));
		});
	}

	@Override
	protected List<String> tabComplete() {
		return args.length == 1 ? completeLastWord("confirm") : NO_COMPLETE;
	}
}
