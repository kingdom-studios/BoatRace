package pl.kingdomcraft.captainhook;

import org.mineacademy.fo.Common;
import org.mineacademy.fo.model.HookManager;
import org.mineacademy.fo.plugin.SimplePlugin;

import pl.kingdomcraft.captainhook.coins.KingdomCoins;
import pl.kingdomcraft.captainhook.database.Database;
import pl.kingdomcraft.captainhook.settings.Settings;
import pl.kingdomcraft.captainhook.stats.StatsSync;

/**
 * Captain Hook - links Minecraft accounts with kingdomcraft.pl (web API), writes player stats to the network
 * database read by the website and runs the network-wide KingdomCoins currency.
 *
 * Commands, listeners, placeholders, settings and localization are registered automatically by Foundation.
 */
public final class CaptainHook extends SimplePlugin {

	@Override
	protected void onPluginStart() {
	}

	/**
	 * Foundation calls this before onPluginStart and again on every reload.
	 */
	@Override
	protected void onReloadablesStart() {
		if ("CHANGE-ME".equals(Settings.Api.SECRET))
			Common.warning("api.secret in config.yml is not set, all web API requests will be rejected!");

		if (!HookManager.isVaultLoaded())
			Common.warning("Vault (or an economy plugin) is missing, player balances will be saved as 0.");

		if (Database.connect())
			StatsSync.resetOnlineFlags(); // queued before the first save, the database thread runs tasks in order

		KingdomCoins.start();
		StatsSync.start();
	}

	@Override
	protected void onPluginPreReload() {
		StatsSync.stop();
		KingdomCoins.stop();
	}

	@Override
	protected void onPluginStop() {
		StatsSync.shutdown();
		KingdomCoins.stop();
		Database.shutdown();
	}

	public static CaptainHook getInstance() {
		return (CaptainHook) SimplePlugin.getInstance();
	}
}
