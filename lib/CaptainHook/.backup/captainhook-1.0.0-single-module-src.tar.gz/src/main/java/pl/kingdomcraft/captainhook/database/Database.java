package pl.kingdomcraft.captainhook.database;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.mineacademy.fo.Common;
import org.mineacademy.fo.database.SimpleDatabase;
import org.mineacademy.fo.plugin.SimplePlugin;

import pl.kingdomcraft.captainhook.settings.Settings;

/**
 * MySQL database with automatic SQLite fallback.
 *
 * Foundation's SimpleDatabase holds a single connection, so every query runs on one dedicated thread
 * ({@link #submit(SqlTask)}). This keeps transactions isolated and per-player operations ordered,
 * while never touching the main thread.
 */
public final class Database extends SimpleDatabase {

	public static final String SQLITE_FILE = "database.db";

	/**
	 * Re-validating the connection costs a round trip, so only do it after it has been idle for a while.
	 */
	private static final long VALIDATE_AFTER_MILLIS = 30_000;

	private static final int MAX_ATTEMPTS = 3;

	/**
	 * CA that signed the database server certificate (private CA, not in the JVM trust store), bundled in the jar.
	 */
	private static final String CA_RESOURCE = "db-ca.pem";

	/**
	 * Trust store built from {@link #CA_RESOURCE} on every connect. It only holds the public CA certificate,
	 * so its password protects integrity, not secrecy.
	 */
	private static final String TRUSTSTORE_FILE = "db-truststore.p12";
	private static final String TRUSTSTORE_PASSWORD = "captainhook";

	private static Database instance;
	private static ExecutorService executor;

	private long lastUsed;

	private Database() {
	}

	/**
	 * Connects to MySQL if enabled and reachable, otherwise to SQLite. Blocking, does nothing when already
	 * connected, so plugin reloads keep the connection (database changes require a restart).
	 *
	 * @return true if a new connection was made (server startup), false if already connected (reload)
	 */
	public static boolean connect() {
		if (executor != null)
			return false;

		executor = Executors.newSingleThreadExecutor(runnable -> {
			final Thread thread = new Thread(runnable, "CaptainHook-Database");

			thread.setDaemon(true);
			return thread;
		});

		instance = Settings.Database.MYSQL_ENABLED ? connectMySql() : null;

		if (instance == null)
			instance = openSqlite(new File(SimplePlugin.getData(), SQLITE_FILE));

		submit(connection -> {
			createTables(connection, instance.isSQLite());

			return null;
		}).join();

		Common.log("Using " + (isMySql() ? "&aMySQL" : "&eSQLite (" + SQLITE_FILE + ")") + "&7 database.");
		return true;
	}

	private static Database connectMySql() {
		final Database database = new Database();

		try {
			database.connect("jdbc:mysql://" + Settings.Database.HOST + ":" + Settings.Database.PORT + "/" + Settings.Database.NAME + "?" + withTrustStore(Settings.Database.PROPERTIES),
					Settings.Database.USERNAME, Settings.Database.PASSWORD);

			return database;

		} catch (final Throwable t) {
			Common.warning("Could not connect to MySQL (" + t.getClass().getSimpleName() + ": " + t.getMessage() + "), falling back to SQLite!");

			return null;
		}
	}

	/**
	 * Points Connector/J at a trust store with the bundled database CA, unless the properties already name one.
	 */
	private static String withTrustStore(final String properties) throws IOException, GeneralSecurityException {
		if (properties.contains("trustCertificateKeyStoreUrl"))
			return properties;

		final File file = writeTrustStore();

		return properties + (properties.isEmpty() ? "" : "&")
				+ "trustCertificateKeyStoreUrl=" + file.toURI()
				+ "&trustCertificateKeyStoreType=PKCS12"
				+ "&trustCertificateKeyStorePassword=" + TRUSTSTORE_PASSWORD;
	}

	private static File writeTrustStore() throws IOException, GeneralSecurityException {
		final KeyStore store = KeyStore.getInstance("PKCS12");
		store.load(null, null);

		try (InputStream in = SimplePlugin.getInstance().getResource(CA_RESOURCE)) {
			if (in == null)
				throw new IOException(CA_RESOURCE + " is missing from the plugin jar");

			int index = 0;

			for (final Certificate certificate : CertificateFactory.getInstance("X.509").generateCertificates(in))
				store.setCertificateEntry("db-ca-" + index++, certificate);

			if (index == 0)
				throw new IOException(CA_RESOURCE + " contains no certificate");
		}

		final File file = new File(SimplePlugin.getData(), TRUSTSTORE_FILE);

		try (OutputStream out = new FileOutputStream(file)) {
			store.store(out, TRUSTSTORE_PASSWORD.toCharArray());
		}

		return file;
	}

	/**
	 * Opens another SQLite file (e.g. the old fallback database), runs the task on it and closes it.
	 * Call from the database thread.
	 */
	public static <T> T withSqlite(final File file, final SqlTask<T> task) throws SQLException {
		final Database database = openSqlite(file);

		try {
			return database.execute(task);

		} finally {
			database.close();
		}
	}

	private static Database openSqlite(final File file) {
		final Database database = new Database();

		database.connect("jdbc:sqlite:" + file.getAbsolutePath());
		return database;
	}

	/**
	 * Waits for queued queries to finish and closes the connection.
	 */
	public static void shutdown() {
		if (executor == null)
			return;

		executor.shutdown();

		try {
			if (!executor.awaitTermination(10, TimeUnit.SECONDS))
				Common.warning("Database queries did not finish within 10 seconds, some changes may be lost!");

		} catch (final InterruptedException ex) {
			Thread.currentThread().interrupt();
		}

		if (instance != null) // null when even SQLite failed to open
			instance.close();

		executor = null;
	}

	public static boolean isMySql() {
		return !instance.isSQLite();
	}

	/**
	 * Runs the task in a transaction on the database thread. Fails the future with SQLException on database errors.
	 * Transactions killed by a MySQL deadlock (several servers updating the same player) are retried.
	 */
	public static <T> CompletableFuture<T> submit(final SqlTask<T> task) {
		final CompletableFuture<T> future = new CompletableFuture<>();

		executor.execute(() -> {
			for (int attempt = 1;; attempt++)
				try {
					future.complete(instance.execute(task));
					return;

				} catch (final SQLException ex) {
					if (attempt < MAX_ATTEMPTS && "40001".equals(ex.getSQLState()))
						continue;

					future.completeExceptionally(ex);
					return;

				} catch (final Throwable t) {
					future.completeExceptionally(t);
					return;
				}
		});

		return future;
	}

	/**
	 * Runs the task within a transaction on the calling thread.
	 */
	private <T> T execute(final SqlTask<T> task) throws SQLException {
		final Connection connection = this.connection();
		final boolean autoCommit = connection.getAutoCommit();

		try {
			connection.setAutoCommit(false);

			final T result = task.run(connection);

			connection.commit();
			this.lastUsed = System.currentTimeMillis();

			return result;

		} catch (final SQLException | RuntimeException ex) {
			try {
				connection.rollback();
			} catch (final SQLException ignored) {
			}

			this.lastUsed = 0; // re-validate the connection before the next query

			throw ex;

		} finally {
			try {
				connection.setAutoCommit(autoCommit);
			} catch (final SQLException ignored) {
			}
		}
	}

	private Connection connection() throws SQLException {
		if (System.currentTimeMillis() - this.lastUsed > VALIDATE_AFTER_MILLIS && !this.isConnected())
			this.connectUsingLastCredentials();

		final Connection connection = this.getConnection();

		if (connection == null)
			throw new SQLException("Database is not connected");

		return connection;
	}

	private static void createTables(final Connection connection, final boolean sqlite) throws SQLException {
		final String autoIncrement = sqlite ? "INTEGER PRIMARY KEY AUTOINCREMENT" : "BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY";
		final String nameColumn = sqlite ? "VARCHAR(16) NOT NULL COLLATE NOCASE" : "VARCHAR(16) NOT NULL";
		final String tableOptions = sqlite ? "" : " ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

		try (Statement statement = connection.createStatement()) {
			statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + Tables.COINS + " ("
					+ "uuid CHAR(36) NOT NULL PRIMARY KEY, "
					+ "name " + nameColumn + ", "
					+ "balance BIGINT NOT NULL DEFAULT 0, "
					+ "last_seen BIGINT NOT NULL)" + tableOptions);

			statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + Tables.COINS_LOG + " ("
					+ "id " + autoIncrement + ", "
					+ "uuid CHAR(36) NOT NULL, "
					+ "type VARCHAR(16) NOT NULL, "
					+ "amount BIGINT NOT NULL, "
					+ "balance_after BIGINT NOT NULL, "
					+ "actor VARCHAR(36) NOT NULL, "
					+ "server VARCHAR(64) NOT NULL, "
					+ "reason VARCHAR(255), "
					+ "created_at BIGINT NOT NULL)" + tableOptions);

			statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + Tables.STATS + " ("
					+ "server_id VARCHAR(64) NOT NULL, "
					+ "uuid CHAR(36) NOT NULL, "
					+ "nickname VARCHAR(16) NOT NULL, "
					+ "balance DECIMAL(20,2) NOT NULL DEFAULT 0, "
					+ "level INT NOT NULL DEFAULT 0, "
					+ "playtime_seconds BIGINT NOT NULL DEFAULT 0, "
					+ "blocks_placed BIGINT NOT NULL DEFAULT 0, "
					+ "player_kills INT NOT NULL DEFAULT 0, "
					+ "mob_kills INT NOT NULL DEFAULT 0, "
					+ "deaths INT NOT NULL DEFAULT 0, "
					+ "clan_tag VARCHAR(16), "
					+ "online BOOLEAN NOT NULL DEFAULT 0, "
					+ "vanished BOOLEAN NOT NULL DEFAULT 0, "
					+ "last_seen BIGINT NOT NULL, "
					+ "updated_at BIGINT NOT NULL, "
					+ "PRIMARY KEY (server_id, uuid))" + tableOptions);

			statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + Tables.STATS_TOTAL + " ("
					+ "uuid CHAR(36) NOT NULL PRIMARY KEY, "
					+ "nickname VARCHAR(16) NOT NULL, "
					+ "playtime_seconds BIGINT NOT NULL DEFAULT 0, "
					+ "blocks_placed BIGINT NOT NULL DEFAULT 0, "
					+ "player_kills BIGINT NOT NULL DEFAULT 0, "
					+ "mob_kills BIGINT NOT NULL DEFAULT 0, "
					+ "deaths BIGINT NOT NULL DEFAULT 0, "
					+ "online BOOLEAN NOT NULL DEFAULT 0, "
					+ "vanished BOOLEAN NOT NULL DEFAULT 0, "
					+ "last_seen BIGINT NOT NULL, "
					+ "updated_at BIGINT NOT NULL)" + tableOptions);

			// Columns added after the first release (tables created earlier lack them)
			addColumn(statement, sqlite, Tables.STATS, "vanished BOOLEAN NOT NULL DEFAULT 0");
			addColumn(statement, sqlite, Tables.STATS_TOTAL, "vanished BOOLEAN NOT NULL DEFAULT 0");

			createIndex(statement, sqlite, "idx_ch_coins_balance", Tables.COINS, "balance");
			createIndex(statement, sqlite, "idx_ch_coins_name", Tables.COINS, "name");
			createIndex(statement, sqlite, "idx_ch_coins_log_uuid", Tables.COINS_LOG, "uuid, id");
			createIndex(statement, sqlite, "idx_ch_stats_uuid", Tables.STATS, "uuid");

			// One index per leaderboard so the website can read any top list without scanning
			for (final String column : new String[] { "playtime_seconds", "blocks_placed", "player_kills", "mob_kills", "deaths", "updated_at" })
				createIndex(statement, sqlite, "idx_ch_stats_total_" + column, Tables.STATS_TOTAL, column);
		}
	}

	/**
	 * Adds a column to an existing table, ignoring "duplicate column" (MySQL 1060 / SQLite) when it is already there.
	 */
	private static void addColumn(final Statement statement, final boolean sqlite, final String table, final String definition) throws SQLException {
		try {
			statement.executeUpdate("ALTER TABLE " + table + " ADD COLUMN " + definition);

		} catch (final SQLException ex) {
			final boolean duplicate = sqlite ? String.valueOf(ex.getMessage()).contains("duplicate column") : ex.getErrorCode() == 1060;

			if (!duplicate)
				throw ex;
		}
	}

	/**
	 * MySQL has no CREATE INDEX IF NOT EXISTS, so a duplicate index error (1061) is expected there.
	 */
	private static void createIndex(final Statement statement, final boolean sqlite, final String name, final String table, final String columns) throws SQLException {
		try {
			statement.executeUpdate("CREATE INDEX " + (sqlite ? "IF NOT EXISTS " : "") + name + " ON " + table + " (" + columns + ")");

		} catch (final SQLException ex) {
			if (sqlite || ex.getErrorCode() != 1061)
				throw ex;
		}
	}

	@FunctionalInterface
	public interface SqlTask<T> {
		T run(Connection connection) throws SQLException;
	}

	public static final class Tables {
		public static final String COINS = "ch_kingdomcoins";
		public static final String COINS_LOG = "ch_kingdomcoins_log";
		public static final String STATS = "ch_player_stats";
		public static final String STATS_TOTAL = "ch_player_stats_total";
	}
}
