package pl.kingdomcraft.captainhook.command.admin;

import org.mineacademy.fo.command.SimpleSubCommand;
import org.mineacademy.fo.model.Replacer;

import pl.kingdomcraft.captainhook.Permissions;
import pl.kingdomcraft.captainhook.database.Database;
import pl.kingdomcraft.captainhook.database.SqliteMerge;
import pl.kingdomcraft.captainhook.settings.Localization.Admin;
import pl.kingdomcraft.captainhook.settings.Settings;
import pl.kingdomcraft.captainhook.stats.StatsSync;

/**
 * /captainhook status
 */
final class StatusSubCommand extends SimpleSubCommand {

	StatusSubCommand() {
		super("status");

		setDescription(Admin.DESCRIPTION_STATUS);
		setPermission(Permissions.ADMIN);
	}

	@Override
	protected void onCommand() {
		tell(Replacer.replaceArray(Admin.STATUS,
				"server", Settings.Api.SERVER_ID,
				"database", Database.isMySql() ? "MySQL" : "SQLite",
				"pending", StatsSync.getPendingCount(),
				"sqlite_file", Database.isMySql() && SqliteMerge.getFile().exists() ? Admin.SQLITE_FILE_PRESENT : "-"));
	}
}
