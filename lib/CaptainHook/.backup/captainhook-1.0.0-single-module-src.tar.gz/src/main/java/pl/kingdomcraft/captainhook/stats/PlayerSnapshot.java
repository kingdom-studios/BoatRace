package pl.kingdomcraft.captainhook.stats;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.mineacademy.fo.model.HookManager;
import org.mineacademy.fo.remain.Remain;

import pl.kingdomcraft.captainhook.hook.VanishHook;

/**
 * Immutable absolute stats of one player on this server, one row of ch_player_stats.
 */
final class PlayerSnapshot {

	final UUID uuid;
	final String nickname;
	final BigDecimal balance;
	final int level;
	final long playtimeSeconds;
	final long blocksPlaced;
	final int playerKills;
	final int mobKills;
	final int deaths;
	final String clanTag;
	final boolean online;
	/**
	 * Online in vanish (SuperVanish): the website shows the player as offline.
	 */
	final boolean vanished;
	final long lastSeen;

	private PlayerSnapshot(final Player player, final boolean online) {
		final double balance = HookManager.getBalance(player);

		this.uuid = player.getUniqueId();
		this.nickname = player.getName();
		this.balance = Double.isFinite(balance) ? BigDecimal.valueOf(balance).setScale(2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
		this.level = player.getLevel();
		this.playtimeSeconds = Remain.getPlaytimeSeconds(player);
		this.blocksPlaced = StatsTracker.getBlocksPlaced(player);
		this.playerKills = player.getStatistic(Statistic.PLAYER_KILLS);
		this.mobKills = player.getStatistic(Statistic.MOB_KILLS);
		this.deaths = player.getStatistic(Statistic.DEATHS);
		this.clanTag = null; // TODO hook the clan plugin once chosen
		this.online = online;
		this.vanished = online && VanishHook.isVanished(player);
		this.lastSeen = System.currentTimeMillis() / 1000;
	}

	/**
	 * Must be called on the main thread (Vault and statistics are not thread-safe).
	 *
	 * @param online false for players leaving the server
	 */
	static PlayerSnapshot of(final Player player, final boolean online) {
		return new PlayerSnapshot(player, online);
	}
}
