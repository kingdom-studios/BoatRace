package pl.kingdomcraft.captainhook.database;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CompletableFuture;

import org.mineacademy.fo.Common;
import org.mineacademy.fo.plugin.SimplePlugin;

import pl.kingdomcraft.captainhook.coins.CoinStore;
import pl.kingdomcraft.captainhook.coins.KingdomCoins;
import pl.kingdomcraft.captainhook.stats.StatsStore;

/**
 * Merges the SQLite fallback database into MySQL once the server is connected to MySQL again.
 *
 * - KingdomCoins: the SQLite database starts empty, so it only holds coins earned during the outage and its
 *   balances are ADDED to MySQL. The transaction log is copied.
 * - Stats: rows newer than in MySQL replace them (they are absolute snapshots), network totals are recomputed.
 *
 * Everything runs in one MySQL transaction, then the file is renamed so it can never be merged twice.
 * If the rename fails, the whole merge is rolled back.
 */
public final class SqliteMerge {

	private SqliteMerge() {
	}

	public static File getFile() {
		return new File(SimplePlugin.getData(), Database.SQLITE_FILE);
	}

	/**
	 * @return {coin accounts, coins} stored in the SQLite file
	 */
	public static CompletableFuture<long[]> preview() {
		return Database.submit(ignored -> Database.withSqlite(getFile(), CoinStore::summarize));
	}

	/**
	 * @return {coin accounts, coins, stats rows} merged
	 */
	public static CompletableFuture<long[]> merge() {
		if (!Database.isMySql())
			throw new IllegalStateException("Merging requires MySQL");

		return Database.submit(target -> {
			final File file = getFile();
			final long[] merged = Database.withSqlite(file, source -> {
				final long[] coins = CoinStore.merge(source, target, false);

				return new long[] { coins[0], coins[1], StatsStore.merge(source, target, false) };
			});

			final File renamed = new File(file.getParentFile(), file.getName() + ".merged-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()));

			try {
				Files.move(file.toPath(), renamed.toPath());

			} catch (final IOException ex) {
				throw new SQLException("Merged, but could not rename " + file.getName() + ", rolling back to prevent merging twice", ex);
			}

			return merged;

		}).whenComplete((merged, error) -> {
			if (error == null)
				Common.runLater(KingdomCoins::refresh);
		});
	}
}
