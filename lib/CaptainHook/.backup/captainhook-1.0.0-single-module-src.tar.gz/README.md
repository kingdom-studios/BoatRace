# Captain Hook

Paper plugin for the KingdomCraft network (built on MineAcademy Foundation):

- links Minecraft accounts with kingdomcraft.pl through the signed web API (`/link`),
- writes player stats to the network MySQL database every few seconds, where the website reads them,
- runs **KingdomCoins**, the network-wide premium currency, on the same database with an automatic SQLite fallback.

The website integration (API, tables, queries) is described in `docs/brief-dla-strony.md`.

## Commands

| Command | Permission | |
|---|---|---|
| `/link [kod]` | – | Link status / link the account with a 6-digit code |
| `/kc` · `/kc balance [gracz]` | – · `captainhook.kingdomcoins.balance.others` | Own / another player's balance |
| `/kc pay <gracz> <ilość>` | – | Send coins (works across servers) |
| `/kc top` | – | Top 10 (cached) |
| `/kc give\|take\|set <gracz> <ilość> [powód]` | `captainhook.kingdomcoins.admin` | Change a balance (logged) |
| `/kc history <gracz> [strona]` | `captainhook.kingdomcoins.admin` | Transaction log |
| `/captainhook status\|reload` | `captainhook.admin` | Database mode, stats queue, reload |
| `/captainhook merge [confirm]` | `captainhook.admin` | Merge coins and stats from the old SQLite fallback into MySQL |

`/kc` aliases are configurable (`kingdomcoins.command-aliases`).

## Placeholders (PlaceholderAPI)

All are served from memory, so they are safe for scoreboards.

| Placeholder | Value |
|---|---|
| `%captainhook_kingdomcoins%` | Viewer's balance, e.g. `1250000` |
| `%captainhook_kingdomcoins_formatted%` | Viewer's balance, e.g. `1 250 000` |
| `%captainhook_kingdomcoins_top_<1-10>_name%` | Player name at that top position |
| `%captainhook_kingdomcoins_top_<1-10>%` | Formatted balance at that top position |

## Stats

Stats live in `ch_player_stats` (one row per server and player) and `ch_player_stats_total` (network-wide sums, one indexed
column per leaderboard). Players whose stats changed (kills, deaths, placed blocks, join/quit) are saved in one batch every
`stats.realtime-interval-seconds` (default 5 s), and everyone online every `stats.sync-interval-minutes` (playtime and the online heartbeat).
Values come from vanilla statistics, so they include history from before the plugin was installed.

## Database

- MySQL is used when `database.mysql.enabled` is true and the connection succeeds. Otherwise the plugin runs on
  `plugins/CaptainHook/database.db` (SQLite) and logs a warning. The mode is chosen on startup, so a restart is needed to switch.
- All balance changes are atomic relative SQL updates (`balance = balance + ?`), so several servers can share one database safely.
  Every change is written to `ch_kingdomcoins_log`.
- When a server that ran on SQLite connects to MySQL again, `/captainhook merge` shows what will be merged and
  `/captainhook merge confirm` **adds** the SQLite balances to MySQL, copies the log and copies stats rows that are newer than in MySQL,
  all in one transaction. Then it renames the file
  to `database.db.merged-<date>` so it cannot be merged twice.
- The JDBC drivers for MySQL and SQLite ship with Paper, so the plugin does not bundle them.

## Setup
1. `mvn package`, then put `target/CaptainHook-<version>.jar` into `plugins/` (Vault and PlaceholderAPI are optional).
2. In `plugins/CaptainHook/config.yml` set `api.server-id`, `api.secret` and `database.mysql.*`, then restart.
3. Keep the server clock NTP-synced, because the website rejects timestamps that are off by more than 60 s.
